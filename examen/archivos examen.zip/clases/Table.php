<?php

class Table 
{
    public static function getData() {
    }

    public static function setData($data) {
    }
}

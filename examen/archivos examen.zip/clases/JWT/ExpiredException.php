<?php
namespace JWT;

class ExpiredException extends \UnexpectedValueException
{

}

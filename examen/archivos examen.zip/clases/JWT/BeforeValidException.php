<?php
namespace JWT;

class BeforeValidException extends \UnexpectedValueException
{

}

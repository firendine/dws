<?php
namespace JWT;

class SignatureInvalidException extends \UnexpectedValueException
{

}

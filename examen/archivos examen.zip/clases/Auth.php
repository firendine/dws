<?php
class Auth {

    static function passwordVerify($user, $password) {
    }

    static function createToken($userName, $admin) {
    }

    static function check() {
    }

}

<?php

class Personajes
{
    public static function getCharacters() {
    }

}

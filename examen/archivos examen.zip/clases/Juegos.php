<?php

class Juegos
{
    public static function getTitle() {
    }

    public static function getDataGame($id) {
    }

}

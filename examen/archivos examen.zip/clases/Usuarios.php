<?php

class Usuarios
{
    public static function getUser($user) {
    }
}

<?php

class DB 
{
    private function __construct(){
    }

    public static function getInstance() {
    }

    public function execQuery($query, $params = null) {
    }

}
